// zx/src/main/java/com/maxrtb/zx/base/BaseAdTracker.kt
package com.maxrtb.zx.base

import com.maxrtb.zx.helper.MacroReplacer
import com.maxrtb.zx.helper.ZXHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * 广告追踪基类
 */
abstract class BaseAdTracker {

    protected val TAG = "AdTracker"

    /**
     * 发送追踪请求
     */
    suspend fun trackEvent(
        url: String,
        requestId: String = "",
        clickId: String = "",
        deviceId: String = "",
        adId: String = "",
    ) {
        if (url.isEmpty()) return

        withContext(Dispatchers.IO) {
            try {
                // 替换宏变量
                val finalUrl = MacroReplacer.replaceMacro(
                    url,
                    requestId = requestId,
                    clickId = clickId,
                    deviceId = deviceId,
                    adId = adId,
                )

                // 发送请求
                val connection = URL(finalUrl).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000

                val responseCode = connection.responseCode
                connection.disconnect()

                ZXHelper.logD(TAG, "Track event: $finalUrl, response: $responseCode")
            } catch (e: Exception) {
                ZXHelper.logE(TAG, "Track event failed: ${e.message}", e)
            }
        }
    }

    /**
     * 批量发送追踪请求
     */
    suspend fun trackEvents(urls: List<String>) {
        urls.forEach { url ->
            trackEvent(url)
        }
    }

    /**
     * 追踪曝光
     */
    abstract suspend fun trackImpression(impressionUrl: String)

    /**
     * 追踪点击
     */
    abstract suspend fun trackClick(clickUrl: String)

    /**
     * 追踪转化
     */
    abstract suspend fun trackConversion(conversionUrl: String)
}
