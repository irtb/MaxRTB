package com.maxrtb.zx.base

import com.maxrtb.zx.listener.ZXBaseListener
import com.maxrtb.zx.model.AdData

abstract class BaseAdAdapter {
    protected var _listener: ZXBaseListener? = null
    protected var _adData: AdData? = null
    
    fun setListener(listener: ZXBaseListener) {
        this._listener = listener
    }
    
    fun setAdData(data: AdData) {
        this._adData = data
    }
    
    abstract suspend fun loadAd(slotId: String): Result<AdData>
    abstract suspend fun showAd(): Result<Unit>
    abstract suspend fun destroyAd()
    
    open fun onAdClicked() { _listener?.onAdClicked() }
    open fun onAdClosed() { _listener?.onAdClosed() }
    open fun onAdLoaded() { _listener?.onAdLoaded() }
    open fun onAdShown() { _listener?.onAdShown() }
    open fun onAdFailed(msg: String) { _listener?.onAdFailed(msg) }
}
